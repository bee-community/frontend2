import React from 'react';
import { Outlet } from 'react-router';

const ChatZone = () => {
  return (
    <>
      {/* <Outlet></Outlet> */}
      <div>ddddd</div>
    </>
  );
};

export default ChatZone;
