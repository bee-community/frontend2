export { default } from './ArticleContent';
