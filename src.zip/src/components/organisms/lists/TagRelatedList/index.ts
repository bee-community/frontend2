export { default } from './TagRelatedList';
