export { default } from './BoardArticleList';
