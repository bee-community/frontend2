export { default } from './CategoryList';
