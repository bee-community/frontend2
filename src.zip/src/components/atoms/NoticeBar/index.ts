export { default } from './NoticeBar';
