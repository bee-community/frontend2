import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  JWTtoken:
    'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJrc3ciLCJleHAiOjE2NTc2MzExNDcsImlhdCI6MTY1NzYxMzE0N30.q9k-08fHxaZEswB1jklmabk-q_NI8oJZBoNc4qE_EMU08zmE7Di1nQ0JgK6aTHyszbQ-7PFmlx6LjgbDpoIPyQ',
};

const tokenSlice = createSlice({
  name: 'JWTtoken',
  initialState,
  reducers: {},
});

// export const { openModal, closeModal } = modalSlice.actions;
export default tokenSlice.reducer;
