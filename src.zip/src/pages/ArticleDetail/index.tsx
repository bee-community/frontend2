import React from 'react';

const ArticleDetail = () => {
  return <>ArticleDetail</>;
};

export default ArticleDetail;
